package main

import "fmt"

var x, y, z = 1, 2, 3
var c, python = true, "python"

func main() {
	fmt.Println(x, y, z, c, python)
}
