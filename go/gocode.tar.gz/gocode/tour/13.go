package main

import "fmt"

func main() {
	var x, y, z = 1, 2, 3
	c, python := true, "python"
	fmt.Println(x, y, z, c, python)
}
