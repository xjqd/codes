package prin

func Sub(x, y int) (ret int, err error) {
	return y - x, err
}
