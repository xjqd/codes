package hello

import "fmt"

func Hello(x string) {
	fmt.Println("hello form ", x)
}
