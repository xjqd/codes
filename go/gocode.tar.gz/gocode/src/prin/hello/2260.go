package hello

import "fmt"

func Abc() {
	fmt.Println("Abc")
}
