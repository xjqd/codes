package main

import "fmt"

func main() {
var i int;
var j int;
var n, m int;
var {
    n1 int
    m1 int
}
var str string;
var arr []int;
var arry [10]int;
var v5 struct {
  f int;
  }
var v6 *int
var v7 map[string]int
var v8 func(a int) int
}
