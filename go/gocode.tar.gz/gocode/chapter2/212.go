package main

import "fmt"

func main() {
	v1 := [2][1][3]int{{{1, 2, 3}}, {{4, 5, 6}}}
	fmt.Println(v1)
}
