package prin

import "fmt"

func sub(x, y int) (ret int, err error) {
	return y - x, err
}
