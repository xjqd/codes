package main

func main() {
	var m map[string]chan bool
	var ch chan int
	ch1 := make(chan int)
}
